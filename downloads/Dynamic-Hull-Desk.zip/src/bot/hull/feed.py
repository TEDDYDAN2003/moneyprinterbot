"""Native MT5 closed-rate clock plus verified, non-committing bid-chart projections."""

from __future__ import annotations

from bisect import bisect_right
from copy import deepcopy
from datetime import UTC, datetime
from math import ceil

from bot.broker import DemoSafetyError
from bot.hull.bar import Bar

from .config import TF_NAME
from .curves import LiveTick
from .entry_clock import CLOCK_SKEW_TOLERANCE_S
from .m45 import BASE, DAY, aggregate, rates8, rates45
from .signal import Hull
from .structure import InternalStructure, Structure


def rates(mt, name, tf, pos, count):
    if tf == 45:
        return rates45(mt, name, pos, count)
    if tf == 8:
        return rates8(mt, name, pos, count)
    period = getattr(mt, "TIMEFRAME_" + TF_NAME[tf])
    return mt.copy_rates_from_pos(name, period, pos, count)


def candle(r):
    return Bar(int(r["time"]), *(float(r[k]) for k in ("open", "high", "low", "close")))


class StructureTape:
    """One independent native structure context per symbol with a TF override.

    Higher TF: last native close at/before chart OPEN. Lower TF: last finished
    native close at/before chart close or trigger tick. Never project a forming
    structure bar. Keep enough context across chart/structure intervals.
    """

    def __init__(self, tf, depth, max_chart_tf, stop_bars):
        self.tf, self.depth = tf, depth
        self.keep = 1000 + ceil((stop_bars + 4) * max_chart_tf / tf)
        self.required = 2 * depth + 2 + ceil((stop_bars + 2) * max_chart_tf / tf)
        self.engine = InternalStructure(depth)
        self.ends, self.views = [], []
        self.ready = False

    def refresh(self, mt, name, now):
        step = self.tf * 60
        reload = not self.ready or not self.ends or now - self.ends[-1] > 3 * step
        rows = rates(mt, name, self.tf, 1, min(self.keep, 999) if reload else 4)
        if rows is None or len(rows) < (self.required if reload else 1):
            self.ready = False
            return "history_unavailable"
        if reload:
            self.engine, self.ends, self.views = InternalStructure(self.depth), [], []
        last, caught_up, gap = -1, 0, False
        for row in rows:
            t = int(row["time"])
            if t <= last:
                raise DemoSafetyError(
                    f"{name} {TF_NAME[self.tf]}: unordered structure history"
                )
            last = t
            if t + step > now or (self.ends and t + step <= self.ends[-1]):
                continue
            gap |= bool(self.ends and t != self.ends[-1])
            view = self.engine.update(candle(row), t + step)
            self.ends.append(t + step)
            self.views.append(view)
            caught_up += 1
        if len(self.ends) > self.keep + 128:
            self.ends, self.views = self.ends[-self.keep :], self.views[-self.keep :]
        self.ready = len(self.ends) >= self.required
        if not self.ready:
            return "history_unavailable"
        return "warmup_only" if reload or gap or caught_up > 1 else "updated"

    def at(self, chart_tf, start, observed):
        cutoff = start if self.tf > chart_tf else observed
        idx = bisect_right(self.ends, cutoff) - 1
        return self.views[idx] if idx >= 0 else Structure()

    def current(self, chart_tf, start, observed):
        v = self.at(chart_tf, start, observed)
        cutoff = start if self.tf > chart_tf else observed
        return (
            self.ready
            and v.closed_s is not None
            and 0 <= cutoff - v.closed_s < self.tf * 60
        )


class Stream:
    def __init__(
        self,
        tf,
        cfg,
        pip,
        external: StructureTape | None = None,
        *,
        tick_size=None,
        price_only=False,
    ):
        self.tf, self.cfg, self.pip, self.ext = tf, cfg, pip, external
        self.price_only = price_only
        self.tick_size = tick_size
        self.h = Hull(tf, cfg, pip, tick_size=tick_size, price_only=price_only)
        self.rebaseline_close = False
        self.history_fence = 0  # never trade a close that predates attachment/recovery
        self.last_label = None
        self.capture_ends = (
            set()
        )  # original candles of live-entry tickets, including on a warm reload
        self.captured = []
        self.shifts = []  # incremental confirmed exits, independent of Hull labels
        self.observed = {}  # live protective notification and confirmed cross have separate keys
        self.baseline_due = True
        self.roll_checked = 0
        self.last_sample = self.last_tick_ms = None
        self.min_bars = max(
            cfg.hull_len + int(cfg.hull_len**0.5) + 2,
            cfg.atr_length + 1,
            2 * cfg.swing_len + 2,
        )

    def refresh(self, mt, name, now):
        self.shifts = []
        self.captured = []
        step = self.tf * 60
        reload = self.h.prev is None or now - self.h.prev.t > step * 4
        rows = rates(
            mt, name, self.tf, 1, min(max(self.min_bars + 2, 999), 999) if reload else 4
        )
        if rows is None or len(rows) < (self.min_bars if reload else 1):
            self.baseline_due = True
            self.rebaseline_close = True
            self.history_fence = max(self.history_fence, now)
            return None, "history_unavailable"
        if reload:
            self.h, self.last_label = (
                Hull(
                    self.tf,
                    self.cfg,
                    self.pip,
                    self.h.gate,
                    tick_size=self.tick_size,
                    price_only=self.price_only,
                ),
                None,
            )
        updates, last, gap, decision = 0, -1, False, None
        for row in rows:
            t = int(row["time"])
            if t <= last:
                raise DemoSafetyError(
                    f"{name} {TF_NAME[self.tf]}: unordered chart bars"
                )
            last = t
            if t + step > now or (self.h.prev and t <= self.h.prev.t):
                continue
            gap |= bool(self.h.prev and t != self.h.prev.t + step)
            context = self.ext.at(self.tf, t, t + step) if self.ext else None
            decision = self.h.update(
                candle(row),
                context=context,
                observe_first=not self.ext or self.ext.current(self.tf, t, t + step),
            )
            # Do not replay startup/reload history. A tracked confirmed exit is not
            # discarded merely because an entry is late, paused or has no Hull cross.
            if not reload and not self.ext and decision.confirmed_mss:
                self.shifts.append(decision)
            if decision.close_s in self.capture_ends:
                self.captured.append(decision)  # exit evidence only; never replay an entry
            if decision.label:
                self.last_label = decision
            updates += 1
        self.h.gate.flush()
        if reload or gap or updates > 1 or self.rebaseline_close:
            self.rebaseline_close = False
            self.baseline_due = True
            self.history_fence = max(self.history_fence, now)
            return None, "warmup_only"
        if decision and decision.close_s <= self.history_fence:
            return None, "warmup_only"  # delayed publication of a pre-attachment close
        if (
            decision
            and self.ext
            and not self.ext.current(self.tf, decision.close_s - step, decision.close_s)
        ):
            return None, "history_unavailable"
        return decision, "updated" if decision else "unchanged"

    def original_close(self, mt, name, end):
        """Repair a missing origin close by date, never by the last available bar.

        WMA on either A source and B has finite memory. Rebuild only the price
        curves, never structure/first-cross state or historical entry decisions.
        """
        read = getattr(mt, "copy_rates_from", None)
        if not read:
            return None
        start = end - self.tf * 60
        # A by-date read may still return index zero at the wall-clock
        # boundary. Require a published CLOSED broker slot at or beyond it.
        if self.h.prev is None or self.h.prev.t < start:
            published = rates(mt, name, self.tf, 1, 1)
            if published is None or not len(published) or int(published[-1]["time"]) < start:
                return None
        n = self.min_bars + 1
        at = lambda t: datetime.fromtimestamp(t, UTC)
        if self.tf == 8:
            base = 240
            rows = read(name, mt.TIMEFRAME_M4, at(end - base), min(999, n * 2 + 1))
            if rows is None or not len(rows):
                return None
            days = mt.copy_rates_range(
                name, mt.TIMEFRAME_D1, at(int(rows[0]["time"]) - DAY), at(end - base)
            )
            rows = (
                aggregate(rows, days, base=base, period=480, bars=2, last_key="last_m4")
                if days is not None
                else None
            )
        else:
            rows = read(
                name, getattr(mt, "TIMEFRAME_" + TF_NAME[self.tf]), at(start), n
            )
        if rows is None or len(rows) < n or int(rows[-1]["time"]) != start:
            return None
        h = Hull(self.tf, self.cfg, self.pip, tick_size=self.tick_size, price_only=True)
        try:
            for row in rows[-n:]:
                r = h.update(candle(row))
        except (ValueError, KeyError, TypeError, OverflowError):
            return (
                None  # never guess the final relation from incomplete or revised data
            )
        return r if r.close_s == end else None

    def boundary_shifts(self, mt, name, now):
        """An order precheck may run across another lane's close. Inspect just
        newly due, contiguous CLOSED bars without committing that lane's Hull,
        first-cross gate or notification cursor. Its next normal poll still sees
        its own entry signals. No warmup replay and no forming-bar structure.
        """
        step = self.tf * 60
        if not self.h.prev or self.ext:
            return []
        last = self.h.prev.t
        if (
            now < max(last + 2 * step, self.roll_checked + step)
            or now - last > 4 * step
        ):
            return []
        rows = rates(mt, name, self.tf, 1, 4)
        if rows is None:
            return []
        engine, events = None, []
        for row in rows:
            t = int(row["time"])
            if t <= self.h.prev.t:
                continue
            if t != last + step or t + step > now:
                break
            if engine is None:
                engine = deepcopy(self.h.structure)
            frame = engine.update(candle(row), t + step)
            if abs(frame.event_code) == 2 and frame.closed_s > self.roll_checked:
                events.append(frame)
            self.roll_checked = max(self.roll_checked, t + step)
            last = t
        return events

    def current_bar(self, mt, name, tick):
        if not self.h.prev:
            return None
        step = self.tf * 60
        start = self.h.prev.t + step
        if not start * 1000 <= tick.ms < (start + step) * 1000:
            return None
        rows = rates(mt, name, self.tf, 0, 1)
        if rows is None or len(rows) != 1:
            return None
        try:
            b = candle(rows[0])
            if self.tf in (8, 45):
                base_sec = 240 if self.tf == 8 else BASE
                last_key = "last_m4" if self.tf == 8 else "last_m15"
                if not rows[0][last_key] <= tick.ms / 1000 < rows[0][last_key] + base_sec:
                    return None
        except (ValueError, TypeError, OverflowError, IndexError, KeyError):
            return None
        if b.t != start:
            return None
        return Bar(b.t, b.o, max(b.h, tick.bid), min(b.l, tick.bid), tick.bid)

    def project(self, mt, name, tick):
        b = self.current_bar(mt, name, tick)
        if b is None or (
            self.ext and not self.ext.current(self.tf, b.t, tick.ms / 1000)
        ):
            return None
        context = self.ext.at(self.tf, b.t, tick.ms / 1000) if self.ext else None
        return self.h.preview(b, tick, context=context)

    def note(self, r, *, baseline=False):
        """One event per (phase, chart candle, direction, selected source, bias, MSS).

        A projection is for protective exits only. It must neither reserve an
        entry nor swallow the independently observed, freshly confirmed cross.
        A real cross on a flip is still a raw exit even when entry is skipped.
        """
        self.observed = {
            k: v for k, v in self.observed.items() if k >= r.close_s - self.tf * 60
        }
        if not r.label:
            return False
        keys = self.observed.setdefault(r.close_s, set())
        key = (
            r.trigger is None,
            r.label,
            r.active_source,
            r.structure.bias,
            r.structure.epoch,
        )
        fresh = key not in keys
        keys.add(key)
        return fresh and not baseline


def sample(mt, name, lanes, clock, max_age):
    """Bracket native candle reads with one unchanged bid/ask/time snapshot.
    A bad lane cannot suppress a protective exit observed on another valid lane.
    """
    q = LiveTick.read(mt.symbol_info_tick(name))
    if not q or not -CLOCK_SKEW_TOLERANCE_S <= clock() - q.ms / 1000 <= max_age:
        return [], False
    readings = [(s, s.project(mt, name, q)) for s in lanes]
    if LiveTick.read(mt.symbol_info_tick(name)) != q:
        return [], False
    now = clock()
    if not -CLOCK_SKEW_TOLERANCE_S <= now - q.ms / 1000 <= max_age:
        return [], False
    out, complete = [], True
    for s, r in readings:
        if not r or r.trigger != q or now >= r.close_s:
            complete = False
            continue
        if s.last_tick_ms is not None and q.ms < s.last_tick_ms:
            complete = False
            s.baseline_due = True
            continue
        resumed = s.last_sample is not None and not 0 <= now - s.last_sample <= max_age
        if s.note(r, baseline=s.baseline_due or resumed):
            out.append(r)
        s.baseline_due = False
        s.last_tick_ms, s.last_sample = q.ms, now
    return out, complete


def verify_before_leg(mt, name, lanes, signal, quote, clock, max_age, on_opposite):
    """Reprice, don't chase: no next leg after an opposite observed during a batch.

    A fresh opposite seen here is serviced even if it vanishes before the next
    outer poll. It never recursively opens a reversal from inside an order send.
    """
    q = LiveTick.read(quote)
    if not q or not -CLOCK_SKEW_TOLERANCE_S <= clock() - q.ms / 1000 <= max_age:
        return False
    lane = lanes[signal.tf]
    r = lane.project(mt, name, q)
    now = clock()
    if (
        LiveTick.read(mt.symbol_info_tick(name)) != q
        or not -CLOCK_SKEW_TOLERANCE_S <= now - q.ms / 1000 <= max_age
        or r is None
        or r.trigger != q
        or now >= r.close_s
        or (lane.last_tick_ms is not None and q.ms < lane.last_tick_ms)
    ):
        return False
    if r.label == -signal.label:
        if lane.note(r, baseline=lane.baseline_due):
            on_opposite(r)
        return False
    if r.structure.bias != signal.label or r.structure.epoch != signal.structure.epoch:
        return False
    # Only the immediate successor candle may supply an executable quote.
    # Do not demand a second cross there, or let its high/low revise the SL.
    return (
        signal.trigger is None
        and q.ms >= signal.close_s * 1000
        and r.close_s == signal.close_s + signal.tf * 60
        and r.active_source == signal.active_source
        and signal.anchor_s == lane.h.prev.t
        and signal.anchor == (lane.h.prev.l if signal.label == 1 else lane.h.prev.h)
        and signal.stop_tick_size is not None
        and signal.stop_tick_size == lane.tick_size
    )
