"""Configuration loading and validation."""

