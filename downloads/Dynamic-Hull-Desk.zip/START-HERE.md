# Dynamic Hull desktop kit

New install: extract into a NEW folder and open README.md. The checked-in template is paper-only; nothing starts automatically. Use the included HullJournal for actual closed demo fills, the MQ5 indicator for chart context, and the profile picker for observation. The charts are not an order manager. For optional paired BUY/SELL pullback limits, read docs/HULL_RETEST.md. The market entry route stays the default.

Existing install: preserve config.demo.local.yaml, reports/hull_runtime, home-directory account state, magic, and the journal output folder containing journal.sqlite3. Do not overlay this kit on your running checkout. Use a verified Git fast-forward while flat, or migrate offline in a copy with backups and the same working directory before restarting. For a separate reporter, --repo points to where the scanner writes its reports and --out to the ORIGINAL journal folder. No private records or credentials are included.

SHA256SUMS.txt covers every other file in this kit. The ZIP contains sources, not Git history; the Git checkout has the downloads link and the packaging tools.
