# FC Hull · chart indicators v3

**Install just the file for your platform. No demo scanner update or restart.**

| Platform | File in this ZIP | How to install |
|---|---|---|
| TradingView | `indicators/FC-Hull-Either-16-Structure.pine` | Paste the complete file into a new Pine Editor indicator → Save → Add to chart. Verify **FC Range 3**. Recreate any alerts tied to the old script. |
| MT5 Desktop | `MT5/FC-Hull-Either-16-Structure.mq5` | File → Open Data Folder → `MQL5/Indicators`. Copy the file there, compile **that file** in MetaEditor (F7), refresh Navigator and attach **FC Hull Range Retest v3**. Do not install as an EA. |

### What counts as an entry?

- **Bullish:** a fresh BUY must be above the BOS-protected HL and at or below the confirmed range midpoint. **Bearish:** a fresh SELL must be at or above the midpoint and below the protected LH. These trend suggestions keep their separate next-open simulation.
- The former opposite zone can **arm a watch**, never a countertrend trade. An opposing Hull signal cancels a watch. Wicks and closes exactly at the guard do not confirm a reversal.
- A strict close above the protected LH or below the protected HL can **stage a chart-only limit at the broken guard** when a matching watch survived or a matching fresh cross occurs on that close. That close is **not** an entry. The first eligible fill is on a later retest. If there is no retest, there is no reversal fill.

Use **Valid suggestions only** (default), or **Simulated fills only** if you want execution bars rather than continuation suggestions. Gold dots show a watch; a blue marker/line shows a limit staged/still waiting. No chart mark submits a broker order.

[Full rules, worked example and OHLC assumptions](docs/HULL_CHART_V3.md) · [MT5 inputs, buffer map and optional local check](MT5/INSTALL-MT5.md) · [Offline verification transcript](verification/RESULTS.txt) · [Two mirrored synthetic example traces](verification/retest-trace.csv).

The second policy mentioned in the docs, `protected_swing_v2`, is the **unchanged demo scanner**, not the v3 charts. Neither the scanner, credentials nor a compiled EX5 is in this package. The optional development QA is not needed to put the studies on your charts.
